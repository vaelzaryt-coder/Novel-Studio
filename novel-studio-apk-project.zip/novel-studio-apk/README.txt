Novel Studio APK builder
1. Create a free GitHub account and a new repository.
2. Upload everything in this folder (keep the .github folder).
3. Open the Actions tab, pick "Build APK", tap Run workflow.
4. When it finishes (about 5 minutes), open the run and download "novel-studio-apk".
5. Unzip it and install app-debug.apk on your phone (allow installs from unknown sources).
